export const environment = {
  production: true,
  baseUrl:'https://api.hlf-k8.tk/'
};
