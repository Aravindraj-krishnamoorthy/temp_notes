open source project
https://github.com/kubernetes-sigs/azurefile-csi-driver/blob/master/docs/driver-parameters.md

other examples
https://github.com/HoussemDellai/aks-file-share/blob/main/static-file-share/azure-file-pv.yaml

https://github.com/mandiladitya/Azure-File-Share-In-AKS/blob/main/Runbook/Steps.md